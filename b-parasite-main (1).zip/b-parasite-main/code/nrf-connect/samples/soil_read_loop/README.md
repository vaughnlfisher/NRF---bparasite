# Calibration
A sample for calibrating b-parasites soil moisture analog-to-digital conversion.
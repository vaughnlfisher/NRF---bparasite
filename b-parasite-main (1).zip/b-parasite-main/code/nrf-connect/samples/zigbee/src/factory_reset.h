#ifndef _PRST_ZB_FACTORY_RESET_H_
#define _PRST_ZB_FACTORY_RESET_H_

int prst_zb_factory_reset_check();

#endif  // _PRST_ZB_FACTORY_RESET_H_
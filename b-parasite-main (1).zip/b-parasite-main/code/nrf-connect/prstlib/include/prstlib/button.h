#ifndef _PRST_BUTTON_H_
#define _PRST_BUTTON_H_

// Inits button driver and registers callback.
int prst_button_init();

#endif  // _PRST_BUTTON_H_
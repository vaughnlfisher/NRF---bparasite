The E73-2G4M08S1C symbol and footprint were borrowed from https://github.com/joric/nrfmicro.
